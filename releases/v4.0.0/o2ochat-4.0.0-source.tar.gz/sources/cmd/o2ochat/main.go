package main

import (
	"fmt"
	"log"
	"os"
	"os/signal"
	"path/filepath"
	"syscall"

	"github.com/netvideo/o2ochat/internal/app"
	"github.com/netvideo/o2ochat/internal/config"
)

const (
	AppName    = "O2OChat"
	AppVersion = "1.0.0"
)

func main() {
	// 解析命令行参数
	flags := config.ParseFlags()

	// 显示版本信息
	if flags.Version {
		printVersion()
		return
	}

	// 显示帮助信息
	if flags.Help {
		return
	}

	// 打印启动信息
	fmt.Printf("%s v%s - P2P Instant Messaging\n", AppName, AppVersion)
	fmt.Println("================================")

	// 加载配置
	cfg, err := loadConfiguration(flags)
	if err != nil {
		log.Fatalf("Failed to load configuration: %v", err)
	}

	// 确保数据目录存在
	if err := os.MkdirAll(cfg.App.DataDir, 0755); err != nil {
		log.Fatalf("Failed to create data directory: %v", err)
	}

	// 创建应用配置
	appConfig := &app.AppConfig{
		ConfigPath: flags.ConfigPath,
		DataDir:    cfg.App.DataDir,
		Debug:      cfg.App.Debug,
	}

	// 创建并启动应用
	application, err := app.NewApplication(appConfig)
	if err != nil {
		log.Fatalf("Failed to create application: %v", err)
	}

	if err := application.Start(); err != nil {
		log.Fatalf("Failed to start application: %v", err)
	}

	log.Println("Application started successfully")

	// 等待中断信号
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

	<-sigChan
	log.Println("Shutting down...")

	if err := application.Stop(); err != nil {
		log.Printf("Error during shutdown: %v", err)
	}

	log.Println("Goodbye!")
}

// printVersion 打印版本信息
func printVersion() {
	fmt.Printf("%s v%s\n", AppName, AppVersion)
	fmt.Println("P2P Instant Messaging Application")
	fmt.Println()
	fmt.Println("Features:")
	fmt.Println("  - End-to-end encryption")
	fmt.Println("  - P2P file transfer")
	fmt.Println("  - Voice and video calls")
	fmt.Println("  - Multi-platform support")
}

// loadConfiguration 加载配置
func loadConfiguration(flags *config.CommandLineFlags) (*config.Config, error) {
	var cfg *config.Config

	// 如果指定了配置文件路径，尝试加载
	if flags.ConfigPath != "" {
		if _, err := os.Stat(flags.ConfigPath); err == nil {
			// 配置文件存在，加载它
			loadedCfg, err := config.LoadConfig(flags.ConfigPath)
			if err != nil {
				return nil, fmt.Errorf("failed to load config file: %w", err)
			}
			cfg = loadedCfg
			log.Printf("Loaded configuration from: %s", flags.ConfigPath)
		}
	}

	// 如果没有加载到配置，使用默认配置
	if cfg == nil {
		cfg = config.DefaultConfig()
		log.Println("Using default configuration")
	}

	// 将命令行参数合并到配置中
	cfg.MergeWithFlags(flags)

	// 如果配置目录不存在，创建它
	configDir := filepath.Dir(cfg.App.ConfigPath)
	if configDir != "" && configDir != "." {
		if err := os.MkdirAll(configDir, 0755); err != nil {
			log.Printf("Warning: failed to create config directory: %v", err)
		}
	}

	// 保存配置到文件（如果不是从文件加载的，或者是默认配置）
	if flags.ConfigPath != "" && cfg.App.ConfigPath != "" {
		if err := config.SaveConfig(cfg, cfg.App.ConfigPath); err != nil {
			log.Printf("Warning: failed to save config file: %v", err)
		} else {
			log.Printf("Configuration saved to: %s", cfg.App.ConfigPath)
		}
	}

	return cfg, nil
}
