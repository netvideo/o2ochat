//go:build windows
// +build windows

package main

import (
	"fmt"
	"log"
	"os"
	"path/filepath"

	"github.com/netvideo/o2ochat/internal/app"
	"github.com/netvideo/o2ochat/internal/config"
)

// Version 和 BuildTime 在构建时注入
var (
	Version   = "dev"
	BuildTime = "unknown"
)

const (
	AppName    = "O2OChat"
	AppVersion = "1.0.0"
)

// getDefaultDataDir 获取 Windows 默认数据目录
func getDefaultDataDir() string {
	// 优先使用 APPDATA 环境变量 (Roaming)
	if appData := os.Getenv("APPDATA"); appData != "" {
		return filepath.Join(appData, "O2OChat")
	}

	// 回退到 LOCALAPPDATA
	if localAppData := os.Getenv("LOCALAPPDATA"); localAppData != "" {
		return filepath.Join(localAppData, "O2OChat")
	}

	// 最后回退到当前目录
	return "./data"
}

// getDefaultConfigPath 获取 Windows 默认配置文件路径
func getDefaultConfigPath() string {
	// 优先使用 APPDATA 环境变量
	if appData := os.Getenv("APPDATA"); appData != "" {
		return filepath.Join(appData, "O2OChat", "config.json")
	}

	// 回退到当前目录
	return "./config.json"
}

func main() {
	// 解析命令行参数
	flags := config.ParseFlags()

	// 显示版本信息
	if flags.Version {
		printVersion()
		return
	}

	// 显示帮助信息
	if flags.Help {
		return
	}

	// 打印启动信息
	fmt.Printf("%s v%s - P2P Instant Messaging\n", AppName, AppVersion)
	fmt.Println("================================")

	// 设置默认路径（如果未指定）
	if flags.DataDir == "" {
		flags.DataDir = getDefaultDataDir()
	}
	if flags.ConfigPath == "" {
		flags.ConfigPath = getDefaultConfigPath()
	}

	// 加载配置
	cfg, err := loadConfiguration(flags)
	if err != nil {
		log.Fatalf("Failed to load configuration: %v", err)
	}

	// 确保数据目录存在
	if err := os.MkdirAll(cfg.App.DataDir, 0755); err != nil {
		log.Fatalf("Failed to create data directory: %v", err)
	}

	// 创建应用配置
	appConfig := &app.AppConfig{
		ConfigPath: flags.ConfigPath,
		DataDir:    cfg.App.DataDir,
		Debug:      cfg.App.Debug,
	}

	// 创建并启动应用
	application, err := app.NewApplication(appConfig)
	if err != nil {
		log.Fatalf("Failed to create application: %v", err)
	}

	if err := application.Start(); err != nil {
		log.Fatalf("Failed to start application: %v", err)
	}

	log.Println("Application started successfully")
	log.Println("Press Ctrl+C to exit")

	// 等待（在真实应用中这里会等待信号）
	select {}
}

// printVersion 打印版本信息
func printVersion() {
	fmt.Printf("%s v%s\n", AppName, AppVersion)
	fmt.Printf("Build Time: %s\n", BuildTime)
	fmt.Println("P2P Instant Messaging Application")
	fmt.Println()
	fmt.Println("Features:")
	fmt.Println("  - End-to-end encryption")
	fmt.Println("  - P2P file transfer")
	fmt.Println("  - Voice and video calls")
	fmt.Println("  - Multi-platform support")
}

// loadConfiguration 加载配置
func loadConfiguration(flags *config.CommandLineFlags) (*config.Config, error) {
	var cfg *config.Config

	// 如果指定了配置文件路径，尝试加载
	if flags.ConfigPath != "" {
		if _, err := os.Stat(flags.ConfigPath); err == nil {
			// 配置文件存在，加载它
			loadedCfg, err := config.LoadConfig(flags.ConfigPath)
			if err != nil {
				return nil, fmt.Errorf("failed to load config file: %w", err)
			}
			cfg = loadedCfg
			log.Printf("Loaded configuration from: %s", flags.ConfigPath)
		}
	}

	// 如果没有加载到配置，使用默认配置
	if cfg == nil {
		cfg = config.DefaultConfig()
		log.Println("Using default configuration")
	}

	// 将命令行参数合并到配置中
	cfg.MergeWithFlags(flags)

	return cfg, nil
}
